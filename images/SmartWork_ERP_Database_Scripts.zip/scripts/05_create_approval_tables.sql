-- ==========================================
-- 05. 전자결재 시스템 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- approval_forms 테이블 (결재 양식)
-- ==========================================
CREATE TABLE approval_forms (
    form_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '양식 ID',
    form_name VARCHAR(100) NOT NULL COMMENT '양식명',
    form_code VARCHAR(50) NOT NULL UNIQUE COMMENT '양식 코드',
    description TEXT NULL COMMENT '양식 설명',
    form_fields JSON NULL COMMENT '양식 필드 정의 (JSON 형태)',
    is_active BOOLEAN NOT NULL DEFAULT TRUE COMMENT '활성화 여부',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_form_code (form_code),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='결재 양식';

-- ==========================================
-- approval_documents 테이블 (결재 문서)
-- ==========================================
CREATE TABLE approval_documents (
    doc_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '문서 ID',
    form_id BIGINT NOT NULL COMMENT '양식 ID',
    doc_number VARCHAR(50) NOT NULL UNIQUE COMMENT '문서 번호 (자동 생성)',
    title VARCHAR(200) NOT NULL COMMENT '제목',
    content JSON NOT NULL COMMENT '문서 내용 (JSON 형태)',
    submitter_id BIGINT NOT NULL COMMENT '기안자 직원 ID',
    status ENUM('DRAFT', 'PENDING', 'APPROVED', 'REJECTED', 'WITHDRAWN') NOT NULL DEFAULT 'DRAFT' COMMENT '문서 상태',
    submitted_at DATETIME NULL COMMENT '상신일시',
    completed_at DATETIME NULL COMMENT '완료일시 (최종 승인/반려)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '작성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_form_id (form_id),
    INDEX idx_doc_number (doc_number),
    INDEX idx_submitter_id (submitter_id),
    INDEX idx_status (status),
    INDEX idx_submitted_at (submitted_at),
    CONSTRAINT fk_doc_form FOREIGN KEY (form_id) REFERENCES approval_forms(form_id),
    CONSTRAINT fk_doc_submitter FOREIGN KEY (submitter_id) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='결재 문서';

-- ==========================================
-- approval_lines 테이블 (결재선)
-- ==========================================
CREATE TABLE approval_lines (
    line_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '결재선 ID',
    doc_id BIGINT NOT NULL COMMENT '문서 ID',
    approver_id BIGINT NOT NULL COMMENT '결재자 직원 ID',
    approval_order INT NOT NULL COMMENT '결재 순서 (1부터 시작)',
    approval_type ENUM('APPROVE', 'REVIEW', 'REFER') NOT NULL DEFAULT 'APPROVE' COMMENT '결재 유형 (승인, 합의, 참조)',
    status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING' COMMENT '결재 상태',
    approved_at DATETIME NULL COMMENT '결재 처리 일시',
    comments TEXT NULL COMMENT '결재 의견',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    INDEX idx_doc_id (doc_id),
    INDEX idx_approver_id (approver_id),
    INDEX idx_status (status),
    INDEX idx_approval_order (approval_order),
    CONSTRAINT fk_line_doc FOREIGN KEY (doc_id) REFERENCES approval_documents(doc_id) ON DELETE CASCADE,
    CONSTRAINT fk_line_approver FOREIGN KEY (approver_id) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='결재선 (결재자 목록)';

-- leave_requests 테이블에 approval_doc_id FK 추가
ALTER TABLE leave_requests
    ADD CONSTRAINT fk_leave_approval FOREIGN KEY (approval_doc_id) REFERENCES approval_documents(doc_id) ON DELETE SET NULL;
