-- ==========================================
-- 07. 공통 테이블 (파일, 알림)
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- files 테이블 (첨부파일)
-- ==========================================
CREATE TABLE files (
    file_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '파일 ID',
    original_name VARCHAR(255) NOT NULL COMMENT '원본 파일명',
    stored_name VARCHAR(255) NOT NULL COMMENT '저장된 파일명 (UUID 등)',
    file_path VARCHAR(500) NOT NULL COMMENT '파일 저장 경로',
    file_size BIGINT NOT NULL COMMENT '파일 크기 (바이트)',
    mime_type VARCHAR(100) NULL COMMENT 'MIME 타입',
    uploaded_by BIGINT NOT NULL COMMENT '업로드한 직원 ID',
    uploaded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '업로드일시',
    reference_type VARCHAR(50) NULL COMMENT '참조 테이블명 (mail, task, chat 등)',
    reference_id BIGINT NULL COMMENT '참조 레코드 ID',
    INDEX idx_uploaded_by (uploaded_by),
    INDEX idx_reference (reference_type, reference_id),
    INDEX idx_uploaded_at (uploaded_at),
    CONSTRAINT fk_file_uploader FOREIGN KEY (uploaded_by) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='첨부파일 (공통)';

-- chat_messages 테이블에 file_id FK 추가
ALTER TABLE chat_messages
    ADD CONSTRAINT fk_message_file FOREIGN KEY (file_id) REFERENCES files(file_id) ON DELETE SET NULL;

-- ==========================================
-- notifications 테이블 (알림)
-- ==========================================
CREATE TABLE notifications (
    notif_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '알림 ID',
    emp_id BIGINT NOT NULL COMMENT '수신자 직원 ID',
    notif_type VARCHAR(50) NOT NULL COMMENT '알림 유형 (APPROVAL, MAIL, CHAT, TASK 등)',
    title VARCHAR(255) NOT NULL COMMENT '알림 제목',
    content TEXT NULL COMMENT '알림 내용',
    reference_type VARCHAR(50) NULL COMMENT '참조 테이블명',
    reference_id BIGINT NULL COMMENT '참조 레코드 ID',
    is_read BOOLEAN NOT NULL DEFAULT FALSE COMMENT '읽음 여부',
    read_at DATETIME NULL COMMENT '읽은 일시',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    INDEX idx_emp_id (emp_id),
    INDEX idx_notif_type (notif_type),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at),
    CONSTRAINT fk_notif_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='알림 (통합)';
