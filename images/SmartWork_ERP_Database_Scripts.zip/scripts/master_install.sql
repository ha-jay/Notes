-- ==========================================
-- SmartWork ERP - 전체 데이터베이스 설치 스크립트
-- ==========================================
-- Version: 1.0
-- Date: 2026-02-14
-- Description: 모든 테이블을 순차적으로 생성하는 마스터 스크립트

-- 실행 방법:
-- mysql -u root -p < master_install.sql
-- 또는 MySQL Workbench에서 직접 실행

-- ==========================================
-- 주의사항
-- ==========================================
-- 1. 이 스크립트는 기존 smartwork_erp 데이터베이스를 삭제합니다.
-- 2. 실행 전 반드시 백업을 수행하세요.
-- 3. 초기 관리자 계정 비밀번호를 반드시 변경하세요.
--    Username: admin
--    Password: admin123

-- ==========================================
-- 스크립트 실행 순서
-- ==========================================

-- 00. 데이터베이스 생성
SOURCE 00_create_database.sql;

-- 01. 공통 및 인증 테이블
SOURCE 01_create_common_tables.sql;

-- 02. 인사 및 출퇴근 관리 테이블
SOURCE 02_create_hr_tables.sql;

-- 03. 프로젝트 관리 테이블
SOURCE 03_create_project_tables.sql;

-- 04. 재고/자산 관리 테이블
SOURCE 04_create_inventory_tables.sql;

-- 05. 전자결재 시스템 테이블
SOURCE 05_create_approval_tables.sql;

-- 06. 메일 및 채팅 시스템 테이블
SOURCE 06_create_communication_tables.sql;

-- 07. 공통 지원 테이블 (파일, 알림)
SOURCE 07_create_common_support_tables.sql;

-- 08. 초기 데이터 삽입
SOURCE 08_insert_initial_data.sql;

-- ==========================================
-- 설치 완료 확인
-- ==========================================
USE smartwork_erp;

SELECT 
    '데이터베이스 설치가 완료되었습니다!' AS status,
    COUNT(*) AS total_tables
FROM information_schema.tables 
WHERE table_schema = 'smartwork_erp';

-- 테이블 목록 확인
SELECT 
    table_name AS '생성된 테이블',
    table_rows AS '레코드 수'
FROM information_schema.tables 
WHERE table_schema = 'smartwork_erp'
ORDER BY table_name;

-- ==========================================
-- 다음 단계
-- ==========================================
-- 1. 관리자 비밀번호 변경
-- 2. 추가 사용자 계정 생성
-- 3. 부서 및 직원 정보 입력
-- 4. 애플리케이션 연결 테스트
