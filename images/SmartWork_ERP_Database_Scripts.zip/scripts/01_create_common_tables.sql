-- ==========================================
-- 01. 공통 및 인증 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- roles 테이블 (역할)
-- ==========================================
CREATE TABLE roles (
    role_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '역할 ID',
    role_name VARCHAR(50) NOT NULL UNIQUE COMMENT '역할명 (ADMIN, MANAGER, EMPLOYEE 등)',
    description VARCHAR(255) NULL COMMENT '역할 설명',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    INDEX idx_role_name (role_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 역할';

-- ==========================================
-- users 테이블 (사용자 계정)
-- ==========================================
CREATE TABLE users (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '사용자 ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '로그인 아이디',
    password VARCHAR(255) NOT NULL COMMENT '암호화된 비밀번호',
    email VARCHAR(100) NOT NULL UNIQUE COMMENT '이메일 주소',
    role_id BIGINT NOT NULL COMMENT '역할 ID',
    is_active BOOLEAN NOT NULL DEFAULT TRUE COMMENT '계정 활성화 여부',
    last_login_at DATETIME NULL COMMENT '마지막 로그인 시간',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role_id (role_id),
    INDEX idx_is_active (is_active),
    CONSTRAINT fk_users_role FOREIGN KEY (role_id) REFERENCES roles(role_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 계정';

-- ==========================================
-- departments 테이블 (부서)
-- ==========================================
CREATE TABLE departments (
    dept_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '부서 ID',
    dept_name VARCHAR(100) NOT NULL UNIQUE COMMENT '부서명',
    parent_dept_id BIGINT NULL COMMENT '상위 부서 ID (자기참조)',
    manager_id BIGINT NULL COMMENT '부서장 직원 ID',
    description TEXT NULL COMMENT '부서 설명',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_parent_dept_id (parent_dept_id),
    INDEX idx_manager_id (manager_id),
    CONSTRAINT fk_dept_parent FOREIGN KEY (parent_dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='부서 정보';

-- ==========================================
-- positions 테이블 (직급)
-- ==========================================
CREATE TABLE positions (
    position_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '직급 ID',
    position_name VARCHAR(50) NOT NULL UNIQUE COMMENT '직급명',
    level INT NOT NULL COMMENT '직급 레벨 (숫자가 높을수록 상위)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    INDEX idx_level (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='직급 정보';
