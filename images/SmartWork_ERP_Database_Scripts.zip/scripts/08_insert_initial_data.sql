-- ==========================================
-- 08. 초기 데이터 삽입
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- 1. 역할(roles) 기본 데이터
-- ==========================================
INSERT INTO roles (role_name, description) VALUES
('ADMIN', '시스템 관리자 - 모든 권한'),
('MANAGER', '부서장/팀장 - 부서 관리 권한'),
('EMPLOYEE', '일반 직원 - 기본 권한'),
('HR', '인사 담당자 - 인사 관리 권한'),
('FINANCE', '재무 담당자 - 재무/회계 권한');

-- ==========================================
-- 2. 직급(positions) 기본 데이터
-- ==========================================
INSERT INTO positions (position_name, level) VALUES
('인턴', 1),
('사원', 2),
('주임', 3),
('대리', 4),
('과장', 5),
('차장', 6),
('부장', 7),
('이사', 8),
('상무', 9),
('전무', 10),
('부사장', 11),
('사장', 12);

-- ==========================================
-- 3. 부서(departments) 기본 데이터
-- ==========================================
INSERT INTO departments (dept_name, parent_dept_id, description) VALUES
('경영지원본부', NULL, '최상위 조직'),
('개발본부', NULL, '최상위 조직'),
('영업본부', NULL, '최상위 조직');

-- 하위 부서
INSERT INTO departments (dept_name, parent_dept_id, description) VALUES
('인사팀', 1, '인사 관리'),
('총무팀', 1, '총무 및 자산 관리'),
('재무팀', 1, '재무 및 회계'),
('백엔드개발팀', 2, '서버 및 API 개발'),
('프론트엔드개발팀', 2, 'UI/UX 및 클라이언트 개발'),
('QA팀', 2, '품질 보증'),
('국내영업팀', 3, '국내 영업'),
('해외영업팀', 3, '해외 영업');

-- ==========================================
-- 4. 관리자 계정 생성
-- ==========================================
-- 비밀번호: admin123 (실제 운영 시 반드시 변경 필요)
-- SHA-256: 240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
INSERT INTO users (username, password, email, role_id, is_active) VALUES
('admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'admin@smartwork.com', 1, TRUE);

-- 관리자 직원 정보
INSERT INTO employees (user_id, emp_number, name, dept_id, position_id, hire_date, status) VALUES
(1, 'EMP00001', '시스템관리자', 1, 12, '2024-01-01', 'ACTIVE');

-- departments 테이블의 manager_id 업데이트 (예시)
UPDATE departments SET manager_id = 1 WHERE dept_id = 1;

-- ==========================================
-- 5. 결재 양식 기본 데이터
-- ==========================================
INSERT INTO approval_forms (form_name, form_code, description, is_active) VALUES
('품의서', 'PURCHASE_REQUEST', '물품 구매 요청 양식', TRUE),
('휴가신청서', 'LEAVE_REQUEST', '휴가 신청 양식', TRUE),
('지출결의서', 'EXPENSE_REPORT', '지출 결의 양식', TRUE),
('출장신청서', 'BUSINESS_TRIP', '출장 신청 양식', TRUE),
('일반기안서', 'GENERAL_PROPOSAL', '일반 기안 양식', TRUE);

-- ==========================================
-- 6. 샘플 재고 카테고리용 품목
-- ==========================================
INSERT INTO inventory_items (item_name, item_code, category, unit, unit_price, current_quantity, min_quantity, location) VALUES
('노트북 (Dell Latitude)', 'IT-NB-001', 'IT장비', '대', 1500000, 10, 3, '자산관리실'),
('모니터 27인치', 'IT-MON-001', 'IT장비', '대', 300000, 15, 5, '자산관리실'),
('무선마우스', 'IT-MOUSE-001', 'IT장비', '개', 30000, 50, 10, '자산관리실'),
('복사용지 A4', 'OF-PAPER-001', '사무용품', '박스', 25000, 100, 20, '창고'),
('볼펜 (흑색)', 'OF-PEN-001', '사무용품', '개', 500, 500, 100, '창고');

-- ==========================================
-- 완료 메시지
-- ==========================================
SELECT '초기 데이터 삽입이 완료되었습니다.' AS message;
SELECT 'Username: admin / Password: admin123 (반드시 변경하세요!)' AS admin_account;
