# SmartWork ERP - 데이터베이스 스크립트

## 📋 개요

SmartWork ERP 시스템의 MySQL 데이터베이스 생성 및 초기화 스크립트입니다.

## 📁 파일 구조

```
database/scripts/
├── 00_create_database.sql          # 데이터베이스 생성
├── 01_create_common_tables.sql     # 공통/인증 테이블
├── 02_create_hr_tables.sql         # 인사/출퇴근 테이블
├── 03_create_project_tables.sql    # 프로젝트 관리 테이블
├── 04_create_inventory_tables.sql  # 재고/자산 테이블
├── 05_create_approval_tables.sql   # 전자결재 테이블
├── 06_create_communication_tables.sql # 메일/채팅 테이블
├── 07_create_common_support_tables.sql # 파일/알림 테이블
├── 08_insert_initial_data.sql      # 초기 데이터 삽입
├── master_install.sql              # 전체 설치 마스터 스크립트
└── 99_drop_database.sql            # 데이터베이스 삭제
```

## 🚀 설치 방법

### 방법 1: 마스터 스크립트 사용 (권장)

```bash
# 모든 스크립트를 한 번에 실행
mysql -u root -p < master_install.sql
```

### 방법 2: 개별 스크립트 실행

```bash
# 순서대로 실행
mysql -u root -p < 00_create_database.sql
mysql -u root -p < 01_create_common_tables.sql
mysql -u root -p < 02_create_hr_tables.sql
mysql -u root -p < 03_create_project_tables.sql
mysql -u root -p < 04_create_inventory_tables.sql
mysql -u root -p < 05_create_approval_tables.sql
mysql -u root -p < 06_create_communication_tables.sql
mysql -u root -p < 07_create_common_support_tables.sql
mysql -u root -p < 08_insert_initial_data.sql
```

### 방법 3: MySQL Workbench 사용

1. MySQL Workbench 실행
2. 데이터베이스 연결
3. File → Open SQL Script → `master_install.sql` 선택
4. 실행 (Lightning 아이콘 클릭)

## ⚙️ 시스템 요구사항

- MySQL 8.0 이상
- 최소 500MB 디스크 공간
- UTF-8 문자셋 지원

## 🔐 초기 관리자 계정

설치 완료 후 다음 계정으로 로그인할 수 있습니다:

- **Username**: `admin`
- **Password**: `admin123`

⚠️ **보안 경고**: 반드시 초기 비밀번호를 변경하세요!

```sql
-- 비밀번호 변경 예시
UPDATE users 
SET password = SHA2('새비밀번호', 256) 
WHERE username = 'admin';
```

## 📊 생성되는 테이블 목록 (총 25개)

### 공통/인증 (4)
- `users` - 사용자 계정
- `roles` - 역할
- `departments` - 부서
- `positions` - 직급

### 인사/출퇴근 (4)
- `employees` - 직원 정보
- `attendance` - 출퇴근 기록
- `leave_requests` - 휴가 신청
- `annual_leaves` - 연차 관리

### 프로젝트 관리 (4)
- `projects` - 프로젝트
- `project_members` - 프로젝트 참여자
- `tasks` - 업무
- `task_comments` - 업무 댓글

### 재고/자산 (3)
- `inventory_items` - 재고 품목
- `inventory_transactions` - 입출고 내역
- `asset_rentals` - 자산 대여

### 전자결재 (3)
- `approval_forms` - 결재 양식
- `approval_documents` - 결재 문서
- `approval_lines` - 결재선

### 메일 시스템 (2)
- `mail_messages` - 메일 메시지
- `mail_recipients` - 메일 수신자

### 채팅 시스템 (3)
- `chat_rooms` - 채팅방
- `chat_participants` - 채팅 참여자
- `chat_messages` - 채팅 메시지

### 공통 지원 (2)
- `files` - 첨부파일
- `notifications` - 알림

## 🔧 초기 데이터

다음 기본 데이터가 자동으로 삽입됩니다:

1. **역할 5개**: ADMIN, MANAGER, EMPLOYEE, HR, FINANCE
2. **직급 12개**: 인턴부터 사장까지
3. **부서 11개**: 3개 본부 + 8개 팀
4. **관리자 계정 1개**: admin / admin123
5. **결재 양식 5개**: 품의서, 휴가신청서 등
6. **샘플 재고 5개**: 노트북, 모니터 등

## 🗑️ 데이터베이스 삭제

```bash
# 주의: 모든 데이터가 영구 삭제됩니다!
mysql -u root -p < 99_drop_database.sql
```

## 📝 커스터마이징

### 데이터베이스명 변경

모든 스크립트에서 `smartwork_erp`를 원하는 이름으로 변경:

```sql
-- 변경 전
CREATE DATABASE smartwork_erp;
USE smartwork_erp;

-- 변경 후
CREATE DATABASE my_company_erp;
USE my_company_erp;
```

### 초기 데이터 수정

`08_insert_initial_data.sql` 파일을 수정하여:
- 부서 구조 변경
- 직급 체계 변경
- 관리자 정보 변경

## 🔍 설치 확인

```sql
USE smartwork_erp;

-- 테이블 목록 확인
SHOW TABLES;

-- 테이블 수 확인 (25개여야 함)
SELECT COUNT(*) FROM information_schema.tables 
WHERE table_schema = 'smartwork_erp';

-- 관리자 계정 확인
SELECT * FROM users WHERE username = 'admin';
```

## ⚡ 성능 최적화

### 인덱스 확인

```sql
-- 특정 테이블의 인덱스 확인
SHOW INDEX FROM employees;
```

### 슬로우 쿼리 로그 활성화

```sql
SET GLOBAL slow_query_log = 'ON';
SET GLOBAL long_query_time = 2;
```

## 🐛 문제 해결

### 외래 키 제약조건 오류

```sql
-- 외래 키 체크 임시 비활성화
SET FOREIGN_KEY_CHECKS=0;
-- 스크립트 실행
SET FOREIGN_KEY_CHECKS=1;
```

### 문자셋 오류

```sql
-- 데이터베이스 문자셋 확인
SHOW VARIABLES LIKE 'character_set%';

-- 테이블 문자셋 변경
ALTER TABLE table_name CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 권한 오류

```sql
-- 사용자 권한 확인
SHOW GRANTS FOR 'username'@'localhost';

-- 권한 부여
GRANT ALL PRIVILEGES ON smartwork_erp.* TO 'username'@'localhost';
FLUSH PRIVILEGES;
```

## 📚 참고 문서

- [MySQL 8.0 Reference Manual](https://dev.mysql.com/doc/refman/8.0/en/)
- [SmartWork ERP ERD 설계서](../docs/ERD설계서.docx)
- [SmartWork ERP 테이블 명세서](../docs/테이블명세서.docx)

## 📧 문의

프로젝트 관련 문의사항은 개발팀에 연락하세요.

---

**Version**: 1.0  
**Last Updated**: 2026-02-14  
**Database**: MySQL 8.0+
