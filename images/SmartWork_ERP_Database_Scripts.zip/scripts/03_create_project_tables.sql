-- ==========================================
-- 03. 프로젝트 관리 (PMS) 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- projects 테이블 (프로젝트)
-- ==========================================
CREATE TABLE projects (
    project_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '프로젝트 ID',
    project_name VARCHAR(200) NOT NULL COMMENT '프로젝트명',
    description TEXT NULL COMMENT '프로젝트 설명',
    start_date DATE NOT NULL COMMENT '시작일',
    end_date DATE NULL COMMENT '종료일 (계획)',
    actual_end_date DATE NULL COMMENT '실제 종료일',
    status ENUM('PLANNING', 'IN_PROGRESS', 'COMPLETED', 'ON_HOLD') NOT NULL DEFAULT 'PLANNING' COMMENT '프로젝트 상태',
    manager_id BIGINT NOT NULL COMMENT 'PM (프로젝트 매니저) 직원 ID',
    budget DECIMAL(15,2) NULL COMMENT '예산',
    progress INT NOT NULL DEFAULT 0 COMMENT '진행률 (0-100%)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_status (status),
    INDEX idx_manager_id (manager_id),
    INDEX idx_start_date (start_date),
    INDEX idx_project_name (project_name),
    CONSTRAINT fk_project_manager FOREIGN KEY (manager_id) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='프로젝트 기본 정보';

-- ==========================================
-- project_members 테이블 (프로젝트 참여자 - N:M 중간 테이블)
-- ==========================================
CREATE TABLE project_members (
    member_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '멤버 ID',
    project_id BIGINT NOT NULL COMMENT '프로젝트 ID',
    emp_id BIGINT NOT NULL COMMENT '직원 ID',
    role VARCHAR(100) NULL COMMENT '프로젝트 내 역할',
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '참여 시작일',
    left_at DATETIME NULL COMMENT '프로젝트 이탈일',
    UNIQUE KEY uk_project_emp (project_id, emp_id) COMMENT '프로젝트-직원 조합 유니크',
    INDEX idx_project_id (project_id),
    INDEX idx_emp_id (emp_id),
    CONSTRAINT fk_member_project FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    CONSTRAINT fk_member_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='프로젝트 참여자';

-- ==========================================
-- tasks 테이블 (업무/작업)
-- ==========================================
CREATE TABLE tasks (
    task_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '업무 ID',
    project_id BIGINT NOT NULL COMMENT '프로젝트 ID',
    task_name VARCHAR(200) NOT NULL COMMENT '업무명',
    description TEXT NULL COMMENT '업무 상세 설명',
    assignee_id BIGINT NULL COMMENT '담당자 직원 ID',
    priority ENUM('HIGH', 'MEDIUM', 'LOW') NOT NULL DEFAULT 'MEDIUM' COMMENT '우선순위',
    status ENUM('TODO', 'IN_PROGRESS', 'DONE', 'BLOCKED') NOT NULL DEFAULT 'TODO' COMMENT '업무 상태',
    progress INT NOT NULL DEFAULT 0 COMMENT '진행률 (0-100%)',
    start_date DATE NULL COMMENT '시작일',
    due_date DATE NULL COMMENT '마감일',
    completed_at DATETIME NULL COMMENT '완료일시',
    parent_task_id BIGINT NULL COMMENT '상위 업무 ID (하위 업무인 경우)',
    created_by BIGINT NOT NULL COMMENT '작성자 직원 ID',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_project_id (project_id),
    INDEX idx_assignee_id (assignee_id),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_due_date (due_date),
    INDEX idx_parent_task_id (parent_task_id),
    CONSTRAINT fk_task_project FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    CONSTRAINT fk_task_assignee FOREIGN KEY (assignee_id) REFERENCES employees(emp_id) ON DELETE SET NULL,
    CONSTRAINT fk_task_creator FOREIGN KEY (created_by) REFERENCES employees(emp_id),
    CONSTRAINT fk_task_parent FOREIGN KEY (parent_task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='업무/작업';

-- ==========================================
-- task_comments 테이블 (업무 댓글)
-- ==========================================
CREATE TABLE task_comments (
    comment_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '댓글 ID',
    task_id BIGINT NOT NULL COMMENT '업무 ID',
    emp_id BIGINT NOT NULL COMMENT '작성자 직원 ID',
    content TEXT NOT NULL COMMENT '댓글 내용',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '작성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    deleted_at DATETIME NULL COMMENT '삭제일시 (소프트 삭제)',
    INDEX idx_task_id (task_id),
    INDEX idx_emp_id (emp_id),
    INDEX idx_created_at (created_at),
    CONSTRAINT fk_comment_task FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE,
    CONSTRAINT fk_comment_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='업무 댓글';
