-- ==========================================
-- SmartWork ERP Database Creation Script
-- ==========================================
-- Version: 1.0
-- Date: 2026-02-14
-- Description: 데이터베이스 생성 및 기본 설정

-- 데이터베이스 생성
DROP DATABASE IF EXISTS smartwork_erp;
CREATE DATABASE smartwork_erp
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE smartwork_erp;

-- 타임존 설정 확인
SELECT @@global.time_zone, @@session.time_zone;

-- 버전 정보 확인
SELECT VERSION();
