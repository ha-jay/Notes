-- ==========================================
-- 06. 메일 및 채팅 시스템 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- mail_messages 테이블 (메일 메시지)
-- ==========================================
CREATE TABLE mail_messages (
    mail_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '메일 ID',
    sender_id BIGINT NOT NULL COMMENT '발신자 직원 ID',
    subject VARCHAR(255) NOT NULL COMMENT '제목',
    body TEXT NOT NULL COMMENT '본문',
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '발송일시',
    parent_mail_id BIGINT NULL COMMENT '원본 메일 ID (답장/전달 시)',
    mail_type ENUM('SENT', 'REPLY', 'FORWARD') NOT NULL DEFAULT 'SENT' COMMENT '메일 유형',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    INDEX idx_sender_id (sender_id),
    INDEX idx_sent_at (sent_at),
    INDEX idx_parent_mail_id (parent_mail_id),
    CONSTRAINT fk_mail_sender FOREIGN KEY (sender_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    CONSTRAINT fk_mail_parent FOREIGN KEY (parent_mail_id) REFERENCES mail_messages(mail_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='메일 메시지';

-- ==========================================
-- mail_recipients 테이블 (메일 수신자)
-- ==========================================
CREATE TABLE mail_recipients (
    recipient_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '수신자 ID',
    mail_id BIGINT NOT NULL COMMENT '메일 ID',
    emp_id BIGINT NOT NULL COMMENT '수신자 직원 ID',
    recipient_type ENUM('TO', 'CC', 'BCC') NOT NULL DEFAULT 'TO' COMMENT '수신자 유형',
    is_read BOOLEAN NOT NULL DEFAULT FALSE COMMENT '읽음 여부',
    read_at DATETIME NULL COMMENT '읽은 일시',
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE COMMENT '삭제 여부',
    deleted_at DATETIME NULL COMMENT '삭제일시',
    INDEX idx_mail_id (mail_id),
    INDEX idx_emp_id (emp_id),
    INDEX idx_is_read (is_read),
    INDEX idx_recipient_type (recipient_type),
    CONSTRAINT fk_recipient_mail FOREIGN KEY (mail_id) REFERENCES mail_messages(mail_id) ON DELETE CASCADE,
    CONSTRAINT fk_recipient_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='메일 수신자';

-- ==========================================
-- chat_rooms 테이블 (채팅방)
-- ==========================================
CREATE TABLE chat_rooms (
    room_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '채팅방 ID',
    room_name VARCHAR(200) NULL COMMENT '채팅방 이름 (그룹 채팅)',
    room_type ENUM('DIRECT', 'GROUP', 'DEPT', 'PROJECT') NOT NULL COMMENT '방 유형',
    dept_id BIGINT NULL COMMENT '부서 ID (부서 채팅방)',
    project_id BIGINT NULL COMMENT '프로젝트 ID (프로젝트 채팅방)',
    created_by BIGINT NOT NULL COMMENT '생성자 직원 ID',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '마지막 메시지 일시',
    INDEX idx_room_type (room_type),
    INDEX idx_dept_id (dept_id),
    INDEX idx_project_id (project_id),
    INDEX idx_created_by (created_by),
    CONSTRAINT fk_room_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE CASCADE,
    CONSTRAINT fk_room_project FOREIGN KEY (project_id) REFERENCES projects(project_id) ON DELETE CASCADE,
    CONSTRAINT fk_room_creator FOREIGN KEY (created_by) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='채팅방';

-- ==========================================
-- chat_participants 테이블 (채팅방 참여자 - N:M 중간 테이블)
-- ==========================================
CREATE TABLE chat_participants (
    participant_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '참여자 ID',
    room_id BIGINT NOT NULL COMMENT '채팅방 ID',
    emp_id BIGINT NOT NULL COMMENT '직원 ID',
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '참여일시',
    last_read_at DATETIME NULL COMMENT '마지막 읽은 시간',
    left_at DATETIME NULL COMMENT '퇴장일시',
    UNIQUE KEY uk_room_emp (room_id, emp_id) COMMENT '채팅방-직원 조합 유니크',
    INDEX idx_room_id (room_id),
    INDEX idx_emp_id (emp_id),
    CONSTRAINT fk_participant_room FOREIGN KEY (room_id) REFERENCES chat_rooms(room_id) ON DELETE CASCADE,
    CONSTRAINT fk_participant_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='채팅방 참여자';

-- ==========================================
-- chat_messages 테이블 (채팅 메시지)
-- ==========================================
CREATE TABLE chat_messages (
    message_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '메시지 ID',
    room_id BIGINT NOT NULL COMMENT '채팅방 ID',
    sender_id BIGINT NOT NULL COMMENT '발신자 직원 ID',
    message_type ENUM('TEXT', 'FILE', 'IMAGE', 'SYSTEM') NOT NULL DEFAULT 'TEXT' COMMENT '메시지 유형',
    content TEXT NULL COMMENT '메시지 내용',
    file_id BIGINT NULL COMMENT '첨부 파일 ID',
    sent_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '발송일시',
    is_deleted BOOLEAN NOT NULL DEFAULT FALSE COMMENT '삭제 여부',
    deleted_at DATETIME NULL COMMENT '삭제일시',
    INDEX idx_room_id (room_id),
    INDEX idx_sender_id (sender_id),
    INDEX idx_sent_at (sent_at),
    INDEX idx_message_type (message_type),
    CONSTRAINT fk_message_room FOREIGN KEY (room_id) REFERENCES chat_rooms(room_id) ON DELETE CASCADE,
    CONSTRAINT fk_message_sender FOREIGN KEY (sender_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='채팅 메시지';
