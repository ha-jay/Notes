-- ==========================================
-- 04. 재고/자산 관리 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- inventory_items 테이블 (재고/자산 품목)
-- ==========================================
CREATE TABLE inventory_items (
    item_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '품목 ID',
    item_name VARCHAR(200) NOT NULL COMMENT '품목명',
    item_code VARCHAR(50) NOT NULL UNIQUE COMMENT '품목 코드',
    category VARCHAR(100) NULL COMMENT '카테고리',
    unit VARCHAR(20) NOT NULL COMMENT '단위 (개, 박스, EA 등)',
    unit_price DECIMAL(15,2) NULL COMMENT '단가',
    current_quantity INT NOT NULL DEFAULT 0 COMMENT '현재 재고 수량',
    min_quantity INT NULL COMMENT '최소 재고량 (알림 기준)',
    location VARCHAR(100) NULL COMMENT '보관 위치',
    barcode VARCHAR(100) NULL UNIQUE COMMENT '바코드/QR코드',
    description TEXT NULL COMMENT '품목 설명',
    image_url VARCHAR(255) NULL COMMENT '이미지 경로',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '등록일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_item_code (item_code),
    INDEX idx_item_name (item_name),
    INDEX idx_category (category),
    INDEX idx_barcode (barcode),
    INDEX idx_current_quantity (current_quantity)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='재고/자산 품목';

-- ==========================================
-- inventory_transactions 테이블 (입출고 내역)
-- ==========================================
CREATE TABLE inventory_transactions (
    trans_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '거래 ID',
    item_id BIGINT NOT NULL COMMENT '품목 ID',
    trans_type ENUM('IN', 'OUT') NOT NULL COMMENT '거래 유형 (IN: 입고, OUT: 출고)',
    quantity INT NOT NULL COMMENT '수량',
    reason VARCHAR(100) NULL COMMENT '사유 (구매, 사용, 폐기 등)',
    emp_id BIGINT NOT NULL COMMENT '처리자 직원 ID',
    trans_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '거래 일시',
    notes TEXT NULL COMMENT '비고',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '기록일시',
    INDEX idx_item_id (item_id),
    INDEX idx_trans_type (trans_type),
    INDEX idx_trans_date (trans_date),
    INDEX idx_emp_id (emp_id),
    CONSTRAINT fk_trans_item FOREIGN KEY (item_id) REFERENCES inventory_items(item_id) ON DELETE CASCADE,
    CONSTRAINT fk_trans_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='입출고 내역';

-- ==========================================
-- asset_rentals 테이블 (자산 대여 기록)
-- ==========================================
CREATE TABLE asset_rentals (
    rental_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '대여 ID',
    item_id BIGINT NOT NULL COMMENT '자산 품목 ID',
    emp_id BIGINT NOT NULL COMMENT '대여자 직원 ID',
    rental_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '대여일시',
    due_date DATETIME NULL COMMENT '반납 예정일',
    return_date DATETIME NULL COMMENT '실제 반납일',
    status ENUM('RENTED', 'RETURNED', 'OVERDUE') NOT NULL DEFAULT 'RENTED' COMMENT '대여 상태',
    notes TEXT NULL COMMENT '비고',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_item_id (item_id),
    INDEX idx_emp_id (emp_id),
    INDEX idx_status (status),
    INDEX idx_due_date (due_date),
    CONSTRAINT fk_rental_item FOREIGN KEY (item_id) REFERENCES inventory_items(item_id) ON DELETE CASCADE,
    CONSTRAINT fk_rental_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='자산 대여 기록';
