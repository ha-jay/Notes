-- ==========================================
-- 02. 인사 및 출퇴근 관리 테이블
-- ==========================================

USE smartwork_erp;

-- ==========================================
-- employees 테이블 (직원 정보)
-- ==========================================
CREATE TABLE employees (
    emp_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '직원 ID',
    user_id BIGINT NOT NULL UNIQUE COMMENT '사용자 ID (1:1 관계)',
    emp_number VARCHAR(20) NOT NULL UNIQUE COMMENT '사번',
    name VARCHAR(100) NOT NULL COMMENT '이름',
    dept_id BIGINT NOT NULL COMMENT '부서 ID',
    position_id BIGINT NOT NULL COMMENT '직급 ID',
    phone VARCHAR(20) NULL COMMENT '전화번호',
    mobile VARCHAR(20) NULL COMMENT '휴대폰 번호',
    address VARCHAR(255) NULL COMMENT '주소',
    birth_date DATE NULL COMMENT '생년월일',
    hire_date DATE NOT NULL COMMENT '입사일',
    resignation_date DATE NULL COMMENT '퇴사일',
    status ENUM('ACTIVE', 'INACTIVE', 'RESIGNED') NOT NULL DEFAULT 'ACTIVE' COMMENT '재직 상태',
    photo_url VARCHAR(255) NULL COMMENT '프로필 사진 경로',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_user_id (user_id),
    INDEX idx_emp_number (emp_number),
    INDEX idx_dept_id (dept_id),
    INDEX idx_position_id (position_id),
    INDEX idx_name (name),
    INDEX idx_status (status),
    CONSTRAINT fk_emp_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_emp_dept FOREIGN KEY (dept_id) REFERENCES departments(dept_id),
    CONSTRAINT fk_emp_position FOREIGN KEY (position_id) REFERENCES positions(position_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='직원 상세 정보';

-- departments 테이블의 manager_id FK 추가 (employees 테이블 생성 후)
ALTER TABLE departments
    ADD CONSTRAINT fk_dept_manager FOREIGN KEY (manager_id) REFERENCES employees(emp_id) ON DELETE SET NULL;

-- ==========================================
-- attendance 테이블 (출퇴근 기록)
-- ==========================================
CREATE TABLE attendance (
    att_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '출퇴근 ID',
    emp_id BIGINT NOT NULL COMMENT '직원 ID',
    work_date DATE NOT NULL COMMENT '근무 날짜',
    check_in DATETIME NULL COMMENT '출근 시간',
    check_out DATETIME NULL COMMENT '퇴근 시간',
    work_hours DECIMAL(5,2) NULL COMMENT '총 근무 시간 (자동 계산)',
    status ENUM('NORMAL', 'LATE', 'EARLY_LEAVE', 'ABSENT') NOT NULL DEFAULT 'NORMAL' COMMENT '근태 상태',
    notes TEXT NULL COMMENT '비고',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    UNIQUE KEY uk_emp_work_date (emp_id, work_date) COMMENT '직원별 날짜 유니크',
    INDEX idx_emp_date (emp_id, work_date),
    INDEX idx_work_date (work_date),
    INDEX idx_status (status),
    CONSTRAINT fk_attendance_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='출퇴근 기록';

-- ==========================================
-- leave_requests 테이블 (휴가 신청)
-- ==========================================
CREATE TABLE leave_requests (
    leave_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '휴가 ID',
    emp_id BIGINT NOT NULL COMMENT '신청자 직원 ID',
    leave_type ENUM('ANNUAL', 'SICK', 'SPECIAL', 'ETC') NOT NULL COMMENT '휴가 유형',
    start_date DATE NOT NULL COMMENT '휴가 시작일',
    end_date DATE NOT NULL COMMENT '휴가 종료일',
    days DECIMAL(4,1) NOT NULL COMMENT '휴가 일수 (반차 포함)',
    reason TEXT NULL COMMENT '휴가 사유',
    approval_doc_id BIGINT NULL COMMENT '결재 문서 ID',
    status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING' COMMENT '승인 상태',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '신청일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    INDEX idx_emp_id (emp_id),
    INDEX idx_status (status),
    INDEX idx_start_date (start_date),
    INDEX idx_leave_type (leave_type),
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='휴가 신청';

-- ==========================================
-- annual_leaves 테이블 (연차 관리)
-- ==========================================
CREATE TABLE annual_leaves (
    annual_id BIGINT AUTO_INCREMENT PRIMARY KEY COMMENT '연차 ID',
    emp_id BIGINT NOT NULL COMMENT '직원 ID',
    year INT NOT NULL COMMENT '연도',
    total_days DECIMAL(4,1) NOT NULL COMMENT '총 연차 일수',
    used_days DECIMAL(4,1) NOT NULL DEFAULT 0 COMMENT '사용한 연차 일수',
    remaining_days DECIMAL(4,1) NOT NULL COMMENT '잔여 연차 (자동 계산)',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '생성일시',
    updated_at DATETIME NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '수정일시',
    UNIQUE KEY uk_emp_year (emp_id, year) COMMENT '직원별 연도 유니크',
    INDEX idx_emp_year (emp_id, year),
    CONSTRAINT fk_annual_emp FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='연차 관리';
