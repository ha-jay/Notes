-- ==========================================
-- SmartWork ERP - 데이터베이스 삭제 스크립트
-- ==========================================
-- 주의: 이 스크립트는 모든 데이터를 영구적으로 삭제합니다!

-- 실행 전 확인
SELECT 
    '경고: 이 스크립트는 smartwork_erp 데이터베이스를 완전히 삭제합니다.' AS warning,
    '계속하려면 아래 DROP 명령의 주석을 제거하세요.' AS instruction;

-- 데이터베이스 삭제 (주석 제거 후 실행)
-- DROP DATABASE IF EXISTS smartwork_erp;

-- 확인
-- SELECT '데이터베이스가 삭제되었습니다.' AS status;
